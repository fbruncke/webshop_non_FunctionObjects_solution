public class Main {

    public static void main(String[] args) {
        WebShop ws = new WebShop();
        ws.buyStuff();
        ws.webShopUI(WebShop.InfoRequest.ShowPurchasePrice);
    }

}
