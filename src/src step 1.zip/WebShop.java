public class WebShop {

    private ShoppingCart shoppingCart = null;

    public enum InfoRequest{
        ShowPurchasePrice,
        ShowVat
    }


    /**
     * Preferred method to buy products
     */
    public void buyStuff()
    {
        this.shoppingCart = new ShoppingCart();

        //Test data
        this.shoppingCart.getItems().add(new Milk(9,"Skim Milk", 5, 1 , 1000));
        this.shoppingCart.getItems().add(new Milk(10,"Whole Milk", 5.5, 1 , 1000));
        this.shoppingCart.getItems().add(new TShirt(100.0,"Fruit of the loom",10.5,150));




    }


    /**
     * Show purchase information to the customer
     */
    public void webShopUI(InfoRequest info)
    {
        switch (info)
        {
            case ShowPurchasePrice:
                System.out.println("Price");
                break;
            case ShowVat:
                System.out.println("Vat");
                break;

        }

    }

}
