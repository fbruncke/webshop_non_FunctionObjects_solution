public class Product {
    private double price;
    private String description;
    private double retailPrice;

    public Product(double price, String description, double retailPrice) {
        this.price = price;
        this.description = description;
        this.retailPrice = retailPrice;
    }
}
