public class TShirt extends Product {
    private double weight;

    public TShirt(double price, String description, double retailPrice, double weight) {
        super(price, description, retailPrice);
        this.weight = weight;
    }
}
