public class Milk extends Product {
    private int volume;
    private double weight;

    public Milk(double price, String description, double retailPrice, int volume, double weight) {
        super(price, description, retailPrice);
        this.volume = volume;
        this.weight = weight;
    }
}
