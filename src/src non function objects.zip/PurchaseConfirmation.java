import java.util.ArrayList;

public class PurchaseConfirmation {


    /**
     * Print all the product descriptions
     * And the Total purchase price
     */
    public void confirmationEmail(ShoppingCart shoppingCart)
    {
        double totPrice = 0;
        ArrayList<Product> items = shoppingCart.getItems();
        for( Product p : items )
        {
            System.out.println(p.getDescription());
            totPrice += p.getPrice();
        }
        System.out.println("Purchase Price : " + totPrice);
    }

}
