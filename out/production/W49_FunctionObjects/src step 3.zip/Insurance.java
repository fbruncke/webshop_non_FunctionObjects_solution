public class Insurance extends Product {
    public Insurance() {
        super(50.0, "Why Bother Insurance", 0, 0);
    }
}
